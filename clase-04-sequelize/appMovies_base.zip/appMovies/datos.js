const peliculas = {
    lista: [
        {
          id: 1,
          title: 'El Padrino',
          length: 175,
          awards: 3
        },
        {
          id: 2,
          title: 'Pulp Fiction',
          length: 154,
          awards: 1
        },
        {
          id: 3,
          title: 'El Señor de los Anillos: La Comunidad del Anillo',
          length: 178,
          awards: 4
        },
        {
          id: 4,
          title: 'Forrest Gump',
          length: 142,
          awards: 6
        },
        {
          id: 5,
          title: 'Parasite',
          length: 132,
          awards: 4
        },
        {
          id: 6,
          title: 'El Club de la Pelea',
          length: 139,
          awards: 0
        }
      ]
};
  
  module.exports = peliculas;