
let mainController = {
    index: function(req, res) {
        //Comentá la línea debajo para poder ver en pantalla lo que traen los modelos
        return res.render("index");
    }

  };


  module.exports = mainController;